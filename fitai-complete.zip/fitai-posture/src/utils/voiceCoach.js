// Voice coaching via Web Speech API — no cost, works offline
let lastSpoken = '';
let lastSpokenTime = 0;
const COOLDOWN_MS = 4000; // don't repeat same message within 4s

export function speak(msg, priority = false) {
  if (!window.speechSynthesis) return;

  const now = Date.now();
  // Debounce: skip if same message said recently (unless priority)
  if (!priority && msg === lastSpoken && now - lastSpokenTime < COOLDOWN_MS) return;

  window.speechSynthesis.cancel(); // cut off any current speech
  const utter = new SpeechSynthesisUtterance(msg);
  utter.rate = 0.95;
  utter.pitch = 1.0;
  utter.volume = 1.0;

  // Pick a natural voice if available
  const voices = window.speechSynthesis.getVoices();
  const preferred = voices.find(v =>
    v.lang.startsWith('en') && (v.name.includes('Google') || v.name.includes('Samantha') || v.name.includes('Daniel'))
  ) || voices.find(v => v.lang.startsWith('en'));
  if (preferred) utter.voice = preferred;

  window.speechSynthesis.speak(utter);
  lastSpoken = msg;
  lastSpokenTime = now;
}

export function speakRepCount(reps) {
  if (reps === 0) return;
  speak(`${reps}`, true);
}

export function speakFeedback(issues) {
  // Only speak the most critical issue
  const error = issues.find(i => i.type === 'error');
  const warn = issues.find(i => i.type === 'warn');
  const ok = issues.find(i => i.type === 'ok');

  if (error) speak(error.msg);
  else if (warn) speak(warn.msg);
  else if (ok) speak('Good form, keep it up');
}

export function cancelSpeech() {
  if (window.speechSynthesis) window.speechSynthesis.cancel();
}
