// Claude API — detailed coaching explanations
// Called only when errors persist for 3+ seconds (not every frame)

const SYSTEM_PROMPT = `You are FitAI, a concise expert fitness coach. 
When given an exercise form issue, respond with ONE sentence of actionable advice.
Be direct and specific. No fluff. Max 20 words. Use plain language, not medical jargon.
Examples:
- "Drive your knees outward as you descend — think about pushing the floor apart."
- "Brace your core like you're about to take a punch, then press."`;

export async function getAICoachAdvice(exercise, issue) {
  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 80,
        system: SYSTEM_PROMPT,
        messages: [{
          role: 'user',
          content: `Exercise: ${exercise}. Issue detected: ${issue}. Give one coaching cue.`
        }]
      })
    });

    if (!response.ok) return null;
    const data = await response.json();
    return data.content?.[0]?.text?.trim() || null;
  } catch {
    return null;
  }
}

export async function getSessionSummary({ exercise, reps, duration, issueLog, goodReps }) {
  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 300,
        system: `You are FitAI, a friendly but honest fitness coach. 
Give a session summary in exactly 3 short paragraphs:
1. Performance overview (what went well)
2. Main form issue to fix (specific, actionable)  
3. What to focus on next session
Keep each paragraph 2 sentences max. Be encouraging but honest.`,
        messages: [{
          role: 'user',
          content: `Session data:
Exercise: ${exercise}
Total reps: ${reps}
Duration: ${Math.floor(duration / 60)}m ${duration % 60}s
Good form reps: ${goodReps} / ${reps}
Issues detected: ${issueLog.join(', ') || 'None'}

Write my session summary.`
        }]
      })
    });

    if (!response.ok) return null;
    const data = await response.json();
    return data.content?.[0]?.text?.trim() || null;
  } catch {
    return null;
  }
}
