// MediaPipe landmark indices
export const LM = {
  NOSE: 0, LEFT_EYE: 2, RIGHT_EYE: 5,
  LEFT_SHOULDER: 11, RIGHT_SHOULDER: 12,
  LEFT_ELBOW: 13, RIGHT_ELBOW: 14,
  LEFT_WRIST: 15, RIGHT_WRIST: 16,
  LEFT_HIP: 23, RIGHT_HIP: 24,
  LEFT_KNEE: 25, RIGHT_KNEE: 26,
  LEFT_ANKLE: 27, RIGHT_ANKLE: 28,
  LEFT_HEEL: 29, RIGHT_HEEL: 30,
  LEFT_FOOT: 31, RIGHT_FOOT: 32,
};

// Calculate angle at point B given three points A-B-C
export function calcAngle(A, B, C) {
  const radians = Math.atan2(C.y - B.y, C.x - B.x) - Math.atan2(A.y - B.y, A.x - B.x);
  let angle = Math.abs((radians * 180.0) / Math.PI);
  if (angle > 180) angle = 360 - angle;
  return Math.round(angle);
}

// Check if landmark is visible enough to use
export function isVisible(lm, threshold = 0.5) {
  return lm && lm.visibility > threshold;
}

// Get midpoint between two landmarks
export function midpoint(A, B) {
  return { x: (A.x + B.x) / 2, y: (A.y + B.y) / 2, visibility: Math.min(A.visibility, B.visibility) };
}

// Exercise-specific angle extraction
export function extractAngles(landmarks, exercise) {
  if (!landmarks || landmarks.length < 33) return null;
  const lm = landmarks;

  const requiredVisible = (indices) => indices.every(i => isVisible(lm[i], 0.4));

  switch (exercise) {
    case 'squat': {
      const needed = [LM.LEFT_HIP, LM.LEFT_KNEE, LM.LEFT_ANKLE, LM.RIGHT_HIP, LM.RIGHT_KNEE, LM.RIGHT_ANKLE];
      if (!requiredVisible(needed)) return null;

      const leftKnee = calcAngle(lm[LM.LEFT_HIP], lm[LM.LEFT_KNEE], lm[LM.LEFT_ANKLE]);
      const rightKnee = calcAngle(lm[LM.RIGHT_HIP], lm[LM.RIGHT_KNEE], lm[LM.RIGHT_ANKLE]);
      const hipMid = midpoint(lm[LM.LEFT_HIP], lm[LM.RIGHT_HIP]);
      const shoulderMid = midpoint(lm[LM.LEFT_SHOULDER], lm[LM.RIGHT_SHOULDER]);
      const vertical = { x: hipMid.x, y: hipMid.y - 1, visibility: 1 };
      const torsoLean = calcAngle(shoulderMid, hipMid, vertical);
      const hipAngle = calcAngle(lm[LM.LEFT_SHOULDER], lm[LM.LEFT_HIP], lm[LM.LEFT_KNEE]);

      // Knee cave: compare knee x to ankle x
      const leftKneeCave = lm[LM.LEFT_KNEE].x < lm[LM.LEFT_ANKLE].x - 0.04;
      const rightKneeCave = lm[LM.RIGHT_KNEE].x > lm[LM.RIGHT_ANKLE].x + 0.04;

      return { leftKnee, rightKnee, torsoLean, hipAngle, leftKneeCave, rightKneeCave };
    }

    case 'pushup': {
      const needed = [LM.LEFT_SHOULDER, LM.LEFT_ELBOW, LM.LEFT_WRIST, LM.LEFT_HIP, LM.LEFT_ANKLE];
      if (!requiredVisible(needed)) return null;

      const elbowAngle = calcAngle(lm[LM.LEFT_SHOULDER], lm[LM.LEFT_ELBOW], lm[LM.LEFT_WRIST]);
      const bodyAngle = calcAngle(lm[LM.LEFT_SHOULDER], lm[LM.LEFT_HIP], lm[LM.LEFT_ANKLE]);
      const elbowFlare = calcAngle(lm[LM.LEFT_HIP], lm[LM.LEFT_SHOULDER], lm[LM.LEFT_ELBOW]);

      return { elbowAngle, bodyAngle, elbowFlare };
    }

    case 'curl': {
      const needed = [LM.LEFT_SHOULDER, LM.LEFT_ELBOW, LM.LEFT_WRIST];
      if (!requiredVisible(needed)) return null;

      const leftCurl = calcAngle(lm[LM.LEFT_SHOULDER], lm[LM.LEFT_ELBOW], lm[LM.LEFT_WRIST]);
      const rightCurl = isVisible(lm[LM.RIGHT_ELBOW])
        ? calcAngle(lm[LM.RIGHT_SHOULDER], lm[LM.RIGHT_ELBOW], lm[LM.RIGHT_WRIST])
        : null;
      const elbowDrift = Math.abs(lm[LM.LEFT_ELBOW].x - lm[LM.LEFT_SHOULDER].x) > 0.08;

      return { leftCurl, rightCurl, elbowDrift };
    }

    case 'plank': {
      const needed = [LM.LEFT_SHOULDER, LM.LEFT_HIP, LM.LEFT_ANKLE];
      if (!requiredVisible(needed)) return null;

      const bodyLine = calcAngle(lm[LM.LEFT_SHOULDER], lm[LM.LEFT_HIP], lm[LM.LEFT_ANKLE]);
      const hipSag = lm[LM.LEFT_HIP].y > Math.max(lm[LM.LEFT_SHOULDER].y, lm[LM.LEFT_ANKLE].y) + 0.05;
      const hipPike = lm[LM.LEFT_HIP].y < Math.min(lm[LM.LEFT_SHOULDER].y, lm[LM.LEFT_ANKLE].y) - 0.05;
      const shoulderAngle = calcAngle(lm[LM.LEFT_ELBOW], lm[LM.LEFT_SHOULDER], lm[LM.LEFT_HIP]);

      return { bodyLine, hipSag, hipPike, shoulderAngle };
    }

    case 'deadlift': {
      const needed = [LM.LEFT_SHOULDER, LM.LEFT_HIP, LM.LEFT_KNEE, LM.LEFT_ANKLE];
      if (!requiredVisible(needed)) return null;

      const backAngle = calcAngle(lm[LM.LEFT_SHOULDER], lm[LM.LEFT_HIP], lm[LM.LEFT_KNEE]);
      const hipHinge = calcAngle(lm[LM.LEFT_SHOULDER], lm[LM.LEFT_HIP], lm[LM.LEFT_ANKLE]);
      const kneeAngle = calcAngle(lm[LM.LEFT_HIP], lm[LM.LEFT_KNEE], lm[LM.LEFT_ANKLE]);

      return { backAngle, hipHinge, kneeAngle };
    }

    case 'ohp': {
      const needed = [LM.LEFT_SHOULDER, LM.LEFT_ELBOW, LM.LEFT_WRIST];
      if (!requiredVisible(needed)) return null;

      const pressAngle = calcAngle(lm[LM.LEFT_SHOULDER], lm[LM.LEFT_ELBOW], lm[LM.LEFT_WRIST]);
      const backArch = calcAngle(
        lm[LM.LEFT_SHOULDER],
        midpoint(lm[LM.LEFT_HIP], lm[LM.RIGHT_HIP]),
        lm[LM.LEFT_ANKLE]
      );
      return { pressAngle, backArch };
    }

    default: return null;
  }
}

// Rep counting state machine
export function detectRepPhase(angles, exercise, prevPhase) {
  if (!angles) return prevPhase;

  switch (exercise) {
    case 'squat': {
      const knee = Math.min(angles.leftKnee, angles.rightKnee);
      if (knee < 100) return 'down';
      if (knee > 160 && prevPhase === 'down') return 'up'; // completed rep
      return prevPhase;
    }
    case 'pushup': {
      if (angles.elbowAngle < 90) return 'down';
      if (angles.elbowAngle > 160 && prevPhase === 'down') return 'up';
      return prevPhase;
    }
    case 'curl': {
      if (angles.leftCurl < 60) return 'up';
      if (angles.leftCurl > 150 && prevPhase === 'up') return 'down';
      return prevPhase;
    }
    case 'plank': return prevPhase;
    case 'deadlift': {
      if (angles.hipHinge < 90) return 'down';
      if (angles.hipHinge > 160 && prevPhase === 'down') return 'up';
      return prevPhase;
    }
    case 'ohp': {
      if (angles.pressAngle > 160) return 'up';
      if (angles.pressAngle < 90 && prevPhase === 'up') return 'down';
      return prevPhase;
    }
    default: return prevPhase;
  }
}

// Generate feedback rules per exercise
export function analyzeForm(angles, exercise) {
  if (!angles) return [];
  const issues = [];

  switch (exercise) {
    case 'squat': {
      const knee = Math.min(angles.leftKnee, angles.rightKnee);
      if (angles.leftKneeCave) issues.push({ type: 'error', msg: 'Left knee caving in — push it out over your pinky toe' });
      if (angles.rightKneeCave) issues.push({ type: 'error', msg: 'Right knee caving in — drive it outward' });
      if (knee > 120 && knee < 160) issues.push({ type: 'warn', msg: `Depth at ${knee}° — go lower, aim for under 100°` });
      if (angles.torsoLean > 60) issues.push({ type: 'warn', msg: 'Too much forward lean — chest up, sit back more' });
      if (knee <= 100 && !angles.leftKneeCave && !angles.rightKneeCave && angles.torsoLean <= 60)
        issues.push({ type: 'ok', msg: 'Great squat form — depth and alignment on point' });
      break;
    }
    case 'pushup': {
      if (angles.elbowFlare > 65) issues.push({ type: 'error', msg: `Elbows flaring at ${angles.elbowFlare}° — keep them at 45° from torso` });
      if (angles.bodyAngle < 160) issues.push({ type: 'error', msg: 'Hips are sagging — brace your core and squeeze glutes' });
      if (angles.bodyAngle > 200) issues.push({ type: 'warn', msg: 'Hips are piking up — lower them to a straight line' });
      if (angles.elbowFlare <= 65 && angles.bodyAngle >= 160 && angles.bodyAngle <= 200)
        issues.push({ type: 'ok', msg: 'Solid push-up form — body line and elbows are good' });
      break;
    }
    case 'curl': {
      if (angles.elbowDrift) issues.push({ type: 'error', msg: 'Elbow drifting forward — pin it to your side' });
      if (angles.leftCurl > 30 && angles.leftCurl < 50) issues.push({ type: 'ok', msg: 'Great curl range — full contraction achieved' });
      if (angles.leftCurl > 160) issues.push({ type: 'warn', msg: 'Extend fully at the bottom for full range of motion' });
      break;
    }
    case 'plank': {
      if (angles.hipSag) issues.push({ type: 'error', msg: 'Hips sagging — squeeze core and glutes, lift up' });
      if (angles.hipPike) issues.push({ type: 'warn', msg: 'Hips too high — lower them to body level' });
      if (angles.bodyLine > 150 && angles.bodyLine < 210)
        issues.push({ type: 'ok', msg: 'Body line straight — core and form are solid' });
      break;
    }
    case 'deadlift': {
      if (angles.backAngle < 130) issues.push({ type: 'error', msg: 'Back rounding detected — neutral spine, chest up' });
      if (angles.kneeAngle > 170) issues.push({ type: 'warn', msg: 'Legs too straight — soften the knees slightly' });
      if (angles.backAngle >= 130) issues.push({ type: 'ok', msg: 'Back position looks solid — maintain through the pull' });
      break;
    }
    case 'ohp': {
      if (angles.backArch < 150) issues.push({ type: 'error', msg: 'Lower back arching — brace core, tuck pelvis' });
      if (angles.pressAngle > 170) issues.push({ type: 'ok', msg: 'Full lockout achieved — arms straight overhead' });
      if (angles.pressAngle < 90) issues.push({ type: 'warn', msg: 'Drive the bar straight up — no forward drift' });
      break;
    }
  }

  return issues;
}

// Draw skeleton on canvas
export function drawSkeleton(ctx, landmarks, canvasWidth, canvasHeight, issues) {
  if (!landmarks || landmarks.length < 33) return;

  const hasError = issues.some(i => i.type === 'error');
  const hasWarn = issues.some(i => i.type === 'warn');
  const lineColor = hasError ? '#ff1744' : hasWarn ? '#ffab00' : '#00e676';

  const connections = [
    [LM.LEFT_SHOULDER, LM.RIGHT_SHOULDER],
    [LM.LEFT_SHOULDER, LM.LEFT_ELBOW], [LM.LEFT_ELBOW, LM.LEFT_WRIST],
    [LM.RIGHT_SHOULDER, LM.RIGHT_ELBOW], [LM.RIGHT_ELBOW, LM.RIGHT_WRIST],
    [LM.LEFT_SHOULDER, LM.LEFT_HIP], [LM.RIGHT_SHOULDER, LM.RIGHT_HIP],
    [LM.LEFT_HIP, LM.RIGHT_HIP],
    [LM.LEFT_HIP, LM.LEFT_KNEE], [LM.LEFT_KNEE, LM.LEFT_ANKLE],
    [LM.RIGHT_HIP, LM.RIGHT_KNEE], [LM.RIGHT_KNEE, LM.RIGHT_ANKLE],
  ];

  ctx.clearRect(0, 0, canvasWidth, canvasHeight);

  // Draw connections
  connections.forEach(([a, b]) => {
    const lmA = landmarks[a], lmB = landmarks[b];
    if (!isVisible(lmA, 0.4) || !isVisible(lmB, 0.4)) return;
    ctx.beginPath();
    ctx.strokeStyle = lineColor;
    ctx.lineWidth = 3;
    ctx.globalAlpha = 0.85;
    ctx.moveTo(lmA.x * canvasWidth, lmA.y * canvasHeight);
    ctx.lineTo(lmB.x * canvasWidth, lmB.y * canvasHeight);
    ctx.stroke();
  });

  // Draw joint dots
  const keyJoints = [
    LM.LEFT_SHOULDER, LM.RIGHT_SHOULDER,
    LM.LEFT_ELBOW, LM.RIGHT_ELBOW,
    LM.LEFT_HIP, LM.RIGHT_HIP,
    LM.LEFT_KNEE, LM.RIGHT_KNEE,
    LM.LEFT_ANKLE, LM.RIGHT_ANKLE,
  ];

  keyJoints.forEach(i => {
    const lm = landmarks[i];
    if (!isVisible(lm, 0.4)) return;
    ctx.beginPath();
    ctx.arc(lm.x * canvasWidth, lm.y * canvasHeight, 5, 0, 2 * Math.PI);
    ctx.fillStyle = '#ffffff';
    ctx.globalAlpha = 0.9;
    ctx.fill();
    ctx.strokeStyle = lineColor;
    ctx.lineWidth = 2;
    ctx.stroke();
  });

  ctx.globalAlpha = 1;
}
