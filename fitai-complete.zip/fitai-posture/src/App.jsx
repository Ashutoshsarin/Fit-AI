import { useState } from 'react';
import Dashboard from './pages/Dashboard';
import BMIPage from './pages/BMIPage';
import DietPage from './pages/DietPage';
import PosturePage from './pages/PosturePage';
import ChatPage from './pages/ChatPage';
import styles from './App.module.css';

const NAV = [
  { id: 'dashboard', label: 'Dashboard', icon: (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><rect x="1" y="1" width="6" height="6" rx="1.5" stroke="currentColor" strokeWidth="1.3"/><rect x="9" y="1" width="6" height="6" rx="1.5" stroke="currentColor" strokeWidth="1.3"/><rect x="1" y="9" width="6" height="6" rx="1.5" stroke="currentColor" strokeWidth="1.3"/><rect x="9" y="9" width="6" height="6" rx="1.5" stroke="currentColor" strokeWidth="1.3"/></svg>
  )},
  { id: 'posture', label: 'Posture coach', icon: (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><circle cx="8" cy="3.5" r="2" stroke="currentColor" strokeWidth="1.3"/><path d="M4 7l2 2 2-3 2 3 2-2" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/><path d="M8 10v5" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round"/></svg>
  )},
  { id: 'bmi', label: 'BMI & health', icon: (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M2 12l3-4 3 2 3-6 3 4" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/></svg>
  )},
  { id: 'diet', label: 'Diet & calories', icon: (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M8 2C5.8 2 4 4 4 6c0 3 4 8 4 8s4-5 4-8c0-2-1.8-4-4-4z" stroke="currentColor" strokeWidth="1.3"/><circle cx="8" cy="6" r="1.5" stroke="currentColor" strokeWidth="1.3"/></svg>
  )},
  { id: 'chat', label: 'AI coach', icon: (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M2 3h12a1 1 0 0 1 1 1v7a1 1 0 0 1-1 1H6l-4 3V4a1 1 0 0 1 1-1z" stroke="currentColor" strokeWidth="1.3" strokeLinejoin="round"/></svg>
  )},
];

const PAGE_TITLES = {
  dashboard: 'Good morning, Ashutosh 👋',
  posture: 'Posture coach',
  bmi: 'BMI & health',
  diet: 'Diet & calories',
  chat: 'AI fitness coach',
};

const today = new Date().toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' });

export default function App() {
  const [page, setPage] = useState('dashboard');

  return (
    <div className={styles.app}>
      {/* Sidebar */}
      <aside className={styles.sidebar}>
        <div className={styles.sidebarTop}>
          <div className={styles.logo}>
            <div className={styles.logoDot}/>
            <div>
              <div className={styles.logoText}>FitAI</div>
              <div className={styles.logoSub}>Posture + Nutrition Coach</div>
            </div>
          </div>
        </div>

        <nav className={styles.nav}>
          {NAV.map(item => (
            <button
              key={item.id}
              className={`${styles.navItem} ${page === item.id ? styles.active : ''}`}
              onClick={() => setPage(item.id)}
            >
              <span className={styles.navIcon}>{item.icon}</span>
              {item.label}
            </button>
          ))}
          <div className={styles.navDivider}/>
          <div className={styles.navSection}>Today</div>
          {[
            { label: '6-day streak 🔥', sub: 'Keep it going' },
            { label: '680 kcal left', sub: 'Under goal' },
            { label: 'Squat session', sub: 'Last detected' },
          ].map(t => (
            <div key={t.label} className={styles.navTip}>
              <div className={styles.navTipLabel}>{t.label}</div>
              <div className={styles.navTipSub}>{t.sub}</div>
            </div>
          ))}
        </nav>

        <div className={styles.sidebarBottom}>
          <div className={styles.userCard}>
            <div className={styles.userAvatar}>AS</div>
            <div>
              <div className={styles.userName}>Ashutosh</div>
              <div className={styles.userPlan}>Day 14 · Free plan</div>
            </div>
          </div>
        </div>
      </aside>

      {/* Main */}
      <div className={styles.content}>
        <div className={styles.topbar}>
          <div className={styles.pageTitle}>{PAGE_TITLES[page]}</div>
          <div className={styles.topbarRight}>
            <div className={styles.streakBadge}>
              <svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M6 1c0 3-3 4-3 7a3 3 0 0 0 6 0c0-3-3-4-3-7z" fill="currentColor"/></svg>
              6-day streak
            </div>
            <div className={styles.dateBadge}>{today}</div>
          </div>
        </div>

        <div className={styles.pageWrap}>
          {page === 'dashboard' && <Dashboard onNavigate={setPage} />}
          {page === 'posture' && <PosturePage />}
          {page === 'bmi' && <BMIPage />}
          {page === 'diet' && <DietPage />}
          {page === 'chat' && <ChatPage />}
        </div>
      </div>
    </div>
  );
}
