import { DEVICE_TIPS } from '../utils/exerciseConfig';
import styles from './DeviceSetup.module.css';

const devices = [
  { id: 'mobile', label: 'Mobile', sub: 'Portrait · 1.5m', icon: (
    <svg width="22" height="30" viewBox="0 0 22 30" fill="none">
      <rect x="1" y="1" width="20" height="28" rx="4" stroke="currentColor" strokeWidth="1.8"/>
      <circle cx="11" cy="25" r="1.5" fill="currentColor"/>
    </svg>
  )},
  { id: 'tablet', label: 'Tablet', sub: 'Landscape · 2m', icon: (
    <svg width="30" height="24" viewBox="0 0 30 24" fill="none">
      <rect x="1" y="1" width="28" height="22" rx="3" stroke="currentColor" strokeWidth="1.8"/>
      <circle cx="26" cy="12" r="1.5" fill="currentColor"/>
    </svg>
  )},
  { id: 'laptop', label: 'Laptop', sub: 'Landscape · 2.5m', icon: (
    <svg width="30" height="24" viewBox="0 0 30 24" fill="none">
      <rect x="3" y="1" width="24" height="17" rx="2" stroke="currentColor" strokeWidth="1.8"/>
      <path d="M1 20h28" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/>
    </svg>
  )},
];

export default function DeviceSetup({ device, onDevice, onNext }) {
  const tips = DEVICE_TIPS[device];

  return (
    <div className={styles.wrap}>
      <div className={styles.heading}>
        <span className={styles.step}>01</span>
        <h2>Select your device</h2>
      </div>

      <div className={styles.deviceRow}>
        {devices.map(d => (
          <button
            key={d.id}
            className={`${styles.deviceBtn} ${device === d.id ? styles.active : ''}`}
            onClick={() => onDevice(d.id)}
          >
            <div className={styles.deviceIcon}>{d.icon}</div>
            <div className={styles.deviceLabel}>{d.label}</div>
            <div className={styles.deviceSub}>{d.sub}</div>
          </button>
        ))}
      </div>

      <div className={styles.tipsBox}>
        <div className={styles.tipsLabel}>Placement guide for {device}</div>
        <div className={styles.tipsGrid}>
          <div className={styles.tip}>
            <div className={styles.tipKey}>Distance</div>
            <div className={styles.tipVal}>{tips.distance}</div>
          </div>
          <div className={styles.tip}>
            <div className={styles.tipKey}>Camera height</div>
            <div className={styles.tipVal}>{tips.height}</div>
          </div>
          <div className={styles.tip}>
            <div className={styles.tipKey}>Orientation</div>
            <div className={styles.tipVal}>{tips.orientation}</div>
          </div>
          <div className={styles.tip}>
            <div className={styles.tipKey}>Pro tip</div>
            <div className={styles.tipVal}>{tips.tip}</div>
          </div>
        </div>
      </div>

      <div className={styles.lightingBox}>
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
          <circle cx="8" cy="8" r="3" stroke="#ffab00" strokeWidth="1.5"/>
          <path d="M8 1v2M8 13v2M1 8h2M13 8h2M3.05 3.05l1.41 1.41M11.54 11.54l1.41 1.41M3.05 12.95l1.41-1.41M11.54 4.46l1.41-1.41" stroke="#ffab00" strokeWidth="1.5" strokeLinecap="round"/>
        </svg>
        <span>Ensure bright, even lighting in front of you. Avoid windows behind you — backlight kills detection accuracy.</span>
      </div>

      <button className={styles.nextBtn} onClick={onNext}>
        Next: frame check
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M3 8h10M9 4l4 4-4 4" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/></svg>
      </button>
    </div>
  );
}
