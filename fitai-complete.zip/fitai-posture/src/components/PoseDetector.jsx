import { useEffect, useRef, useState, useCallback } from 'react';
import { PoseLandmarker, FilesetResolver } from '@mediapipe/tasks-vision';
import { extractAngles, analyzeForm, detectRepPhase, drawSkeleton } from '../utils/poseUtils';
import { EXERCISES } from '../utils/exerciseConfig';
import { speak, speakRepCount, speakFeedback, cancelSpeech } from '../utils/voiceCoach';
import { getAICoachAdvice } from '../utils/claudeCoach';
import styles from './PoseDetector.module.css';

const STATUS = { LOADING: 'loading', READY: 'ready', RUNNING: 'running', PAUSED: 'paused', ERROR: 'error' };

export default function PoseDetector({ exercise, device, onBack, onFinish }) {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const landmarkerRef = useRef(null);
  const animFrameRef = useRef(null);
  const phaseRef = useRef('up');
  const lastFeedbackRef = useRef(0);
  const lastAIRef = useRef(0);
  const errorStreakRef = useRef(0);
  const issueLogRef = useRef([]);
  const goodRepsRef = useRef(0);
  const repsRef = useRef(0);

  const [status, setStatus] = useState(STATUS.LOADING);
  const [loadMsg, setLoadMsg] = useState('Loading AI model (~10MB)...');
  const [feedback, setFeedback] = useState([]);
  const [aiAdvice, setAiAdvice] = useState('');
  const [angles, setAngles] = useState(null);
  const [reps, setReps] = useState(0);
  const [elapsed, setElapsed] = useState(0);
  const [voiceOn, setVoiceOn] = useState(true);
  const [camError, setCamError] = useState('');
  const timerRef = useRef(null);
  const elapsedRef = useRef(0);

  const ex = EXERCISES[exercise];

  // Load MediaPipe
  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        const vision = await FilesetResolver.forVisionTasks(
          'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@latest/wasm'
        );
        if (cancelled) return;
        setLoadMsg('Initializing pose detector...');
        const poseLandmarker = await PoseLandmarker.createFromOptions(vision, {
          baseOptions: {
            modelAssetPath: 'https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/1/pose_landmarker_lite.task',
            delegate: 'GPU',
          },
          runningMode: 'VIDEO',
          numPoses: 1,
          minPoseDetectionConfidence: 0.5,
          minPosePresenceConfidence: 0.5,
          minTrackingConfidence: 0.5,
        });
        if (cancelled) return;
        landmarkerRef.current = poseLandmarker;
        setStatus(STATUS.READY);
        setLoadMsg('');
      } catch (e) {
        if (!cancelled) { setStatus(STATUS.ERROR); setLoadMsg('Failed to load AI model. Check your connection.'); }
      }
    }
    load();
    return () => { cancelled = true; };
  }, []);

  // Start camera
  const startCamera = useCallback(async () => {
    try {
      const isMobile = device === 'mobile';
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: isMobile ? 'environment' : 'user', width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false,
      });
      videoRef.current.srcObject = stream;
      await videoRef.current.play();
      setStatus(STATUS.RUNNING);
      speak(`Starting ${ex.name}. Get into position.`);
      const startTime = Date.now();
      timerRef.current = setInterval(() => {
        const s = Math.floor((Date.now() - startTime) / 1000);
        setElapsed(s);
        elapsedRef.current = s;
      }, 1000);
    } catch (e) {
      setCamError(e.name === 'NotAllowedError'
        ? 'Camera access denied — allow permission and reload.'
        : 'Could not access camera. Is another app using it?');
      setStatus(STATUS.ERROR);
    }
  }, [device, exercise]);

  // Detection loop
  useEffect(() => {
    if (status !== STATUS.RUNNING) return;
    let lastVideoTime = -1;

    function detect() {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      if (!video || !canvas || !landmarkerRef.current) {
        animFrameRef.current = requestAnimationFrame(detect);
        return;
      }

      const now = performance.now();
      if (video.currentTime !== lastVideoTime && video.readyState >= 2) {
        lastVideoTime = video.currentTime;
        const results = landmarkerRef.current.detectForVideo(video, now);

        canvas.width = video.videoWidth || 640;
        canvas.height = video.videoHeight || 480;
        const ctx = canvas.getContext('2d');

        if (results.landmarks && results.landmarks.length > 0) {
          const lms = results.landmarks[0];
          const extracted = extractAngles(lms, exercise);
          const issues = extracted ? analyzeForm(extracted, exercise) : [];

          drawSkeleton(ctx, lms, canvas.width, canvas.height, issues);
          if (extracted) setAngles(extracted);

          // Rep counting
          const newPhase = detectRepPhase(extracted, exercise, phaseRef.current);
          if (newPhase === 'up' && phaseRef.current === 'down') {
            const newReps = repsRef.current + 1;
            repsRef.current = newReps;
            setReps(newReps);
            speakRepCount(newReps);
            // Track good vs bad reps
            const hasErrors = issues.some(i => i.type === 'error');
            if (!hasErrors) goodRepsRef.current += 1;
            // Log unique issues
            issues.filter(i => i.type === 'error').forEach(i => {
              if (!issueLogRef.current.includes(i.msg)) issueLogRef.current.push(i.msg);
            });
          }
          phaseRef.current = newPhase;

          // Throttle feedback display (1/sec)
          if (Date.now() - lastFeedbackRef.current > 1000) {
            setFeedback(issues);
            lastFeedbackRef.current = Date.now();
            if (voiceOn) speakFeedback(issues);
          }

          // Error streak tracking → call Claude for deeper advice (max 1 per 15s)
          const hasError = issues.some(i => i.type === 'error');
          if (hasError) errorStreakRef.current++;
          else errorStreakRef.current = 0;

          if (errorStreakRef.current > 15 && Date.now() - lastAIRef.current > 15000) {
            lastAIRef.current = Date.now();
            const topError = issues.find(i => i.type === 'error');
            if (topError) {
              getAICoachAdvice(exercise, topError.msg).then(advice => {
                if (advice) {
                  setAiAdvice(advice);
                  if (voiceOn) speak(advice);
                  setTimeout(() => setAiAdvice(''), 8000);
                }
              });
            }
          }
        } else {
          ctx.clearRect(0, 0, canvas.width, canvas.height);
          if (Date.now() - lastFeedbackRef.current > 2000) {
            setFeedback([{ type: 'warn', msg: 'No body detected — step fully into frame' }]);
            lastFeedbackRef.current = Date.now();
          }
        }
      }
      animFrameRef.current = requestAnimationFrame(detect);
    }

    animFrameRef.current = requestAnimationFrame(detect);
    return () => cancelAnimationFrame(animFrameRef.current);
  }, [status, exercise, voiceOn]);

  // Cleanup
  useEffect(() => {
    return () => {
      cancelAnimationFrame(animFrameRef.current);
      clearInterval(timerRef.current);
      cancelSpeech();
      if (videoRef.current?.srcObject) videoRef.current.srcObject.getTracks().forEach(t => t.stop());
    };
  }, []);

  const handleFinish = () => {
    cancelAnimationFrame(animFrameRef.current);
    clearInterval(timerRef.current);
    cancelSpeech();
    if (videoRef.current?.srcObject) videoRef.current.srcObject.getTracks().forEach(t => t.stop());
    onFinish({
      exercise,
      reps: repsRef.current,
      duration: elapsedRef.current,
      issueLog: issueLogRef.current,
      goodReps: goodRepsRef.current,
    });
  };

  const formatTime = s => `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
  const statusColor = feedback.some(f => f.type === 'error') ? '#ff1744'
    : feedback.some(f => f.type === 'warn') ? '#ffab00' : '#00e676';

  return (
    <div className={styles.wrap}>
      <div className={styles.header}>
        <button className={styles.backBtn} onClick={onBack}>
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M13 8H3M7 4l-4 4 4 4" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/></svg>
          Back
        </button>
        <div className={styles.exTag}>{ex.icon} {ex.name}</div>
        <div className={styles.rightControls}>
          <button
            className={`${styles.voiceBtn} ${voiceOn ? styles.voiceOn : ''}`}
            onClick={() => { setVoiceOn(v => !v); if (voiceOn) cancelSpeech(); }}
            title={voiceOn ? 'Mute voice' : 'Enable voice'}
          >
            {voiceOn ? (
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M2 5h3l4-3v12l-4-3H2V5zM11 5a4 4 0 0 1 0 6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>
            ) : (
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M2 5h3l4-3v12l-4-3H2V5zM13 6l-3 4M10 6l3 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>
            )}
          </button>
          <div className={styles.timer}>{formatTime(elapsed)}</div>
        </div>
      </div>

      <div className={styles.camWrap}>
        <video ref={videoRef} className={styles.video} playsInline muted
          style={{ transform: device !== 'mobile' ? 'scaleX(-1)' : 'none' }} />
        <canvas ref={canvasRef} className={styles.canvas}
          style={{ transform: device !== 'mobile' ? 'scaleX(-1)' : 'none' }} />

        <div className={styles.frameGuide}>
          <div className={`${styles.corner} ${styles.tl}`}/>
          <div className={`${styles.corner} ${styles.tr}`}/>
          <div className={`${styles.corner} ${styles.bl}`}/>
          <div className={`${styles.corner} ${styles.br}`}/>
        </div>

        {status === STATUS.LOADING && (
          <div className={styles.overlay}>
            <div className={styles.spinner}/>
            <div className={styles.overlayMsg}>{loadMsg}</div>
          </div>
        )}
        {status === STATUS.READY && (
          <div className={styles.overlay}>
            <button className={styles.startBtn} onClick={startCamera}>
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none"><path d="M6 4l12 6-12 6V4z" fill="currentColor"/></svg>
              Start camera
            </button>
            <div className={styles.overlayMsg}>{ex.cue}</div>
          </div>
        )}
        {status === STATUS.ERROR && (
          <div className={styles.overlay}>
            <div className={styles.errorMsg}>{camError || loadMsg}</div>
            {camError && <button className={styles.retryBtn} onClick={() => { setCamError(''); setStatus(STATUS.READY); }}>Try again</button>}
          </div>
        )}
        {status === STATUS.RUNNING && (
          <>
            <div className={styles.repBadge}>{reps}<span>reps</span></div>
            <div className={styles.statusDot} style={{ background: statusColor }}>
              <div className={styles.statusPulse} style={{ background: statusColor }}/>
            </div>
          </>
        )}
      </div>

      {/* AI Coach advice bubble */}
      {aiAdvice && (
        <div className={styles.aiBubble}>
          <div className={styles.aiDot}/>
          <div className={styles.aiMsg}>{aiAdvice}</div>
        </div>
      )}

      {/* Feedback panel */}
      <div className={styles.feedPanel}>
        {feedback.length === 0 ? (
          <div className={styles.feedEmpty}>Waiting for movement...</div>
        ) : (
          feedback.map((f, i) => (
            <div key={i} className={`${styles.feedItem} ${styles[f.type]}`}>
              <div className={styles.feedIcon}>{f.type === 'ok' ? '✓' : f.type === 'error' ? '!' : '~'}</div>
              <div className={styles.feedMsg}>{f.msg}</div>
            </div>
          ))
        )}
      </div>

      {/* Angle readouts */}
      {angles && (
        <div className={styles.anglesRow}>
          {Object.entries(angles)
            .filter(([, v]) => typeof v === 'number')
            .slice(0, 4)
            .map(([key, val]) => {
              const isErr = feedback.some(f => f.type === 'error');
              return (
                <div key={key} className={styles.angleCard}>
                  <div className={styles.angleVal} style={{ color: isErr ? 'var(--amber)' : 'var(--green)' }}>{val}°</div>
                  <div className={styles.angleKey}>{key.replace(/([A-Z])/g, ' $1').trim().toLowerCase()}</div>
                </div>
              );
            })}
        </div>
      )}

      {/* End session */}
      {status === STATUS.RUNNING && (
        <button className={styles.endBtn} onClick={handleFinish}>
          End session & see summary
        </button>
      )}
    </div>
  );
}
