import { EXERCISES } from '../utils/exerciseConfig';
import styles from './ExercisePicker.module.css';

export default function ExercisePicker({ exercise, onExercise, onNext, onBack }) {
  const ex = EXERCISES[exercise];

  return (
    <div className={styles.wrap}>
      <div className={styles.heading}>
        <span className={styles.step}>02</span>
        <h2>Pick your exercise</h2>
      </div>

      <div className={styles.grid}>
        {Object.entries(EXERCISES).map(([id, data]) => (
          <button
            key={id}
            className={`${styles.exBtn} ${exercise === id ? styles.active : ''}`}
            onClick={() => onExercise(id)}
          >
            <span className={styles.exIcon}>{data.icon}</span>
            <span className={styles.exName}>{data.name}</span>
          </button>
        ))}
      </div>

      <div className={styles.infoCard}>
        <div className={styles.infoTop}>
          <div>
            <div className={styles.exTitle}>{ex.name}</div>
            <div className={styles.exMuscles}>{ex.muscles}</div>
          </div>
          <div className={styles.camTag}>
            <svg width="12" height="12" viewBox="0 0 12 12" fill="none"><rect x="1" y="2" width="10" height="8" rx="2" stroke="currentColor" strokeWidth="1.2"/><circle cx="6" cy="6" r="2" stroke="currentColor" strokeWidth="1.2"/></svg>
            {ex.camera}
          </div>
        </div>

        <div className={styles.cueBox}>
          <div className={styles.cueLabel}>Camera setup</div>
          <div className={styles.cueText}>{ex.cue}</div>
        </div>

        <div className={styles.jointsLabel}>Joints being tracked</div>
        <div className={styles.joints}>
          {ex.joints.map(j => (
            <div key={j} className={styles.joint}>
              <div className={styles.jointDot}/>
              {j}
            </div>
          ))}
        </div>
      </div>

      <div className={styles.btnRow}>
        <button className={styles.backBtn} onClick={onBack}>← Back</button>
        <button className={styles.nextBtn} onClick={onNext}>
          Start session
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M3 8h10M9 4l4 4-4 4" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/></svg>
        </button>
      </div>
    </div>
  );
}
