import { useEffect, useState } from 'react';
import { getSessionSummary } from '../utils/claudeCoach';
import { EXERCISES } from '../utils/exerciseConfig';
import styles from './SessionSummary.module.css';

export default function SessionSummary({ exercise, reps, duration, issueLog, goodReps, onRestart, onNewExercise }) {
  const [summary, setSummary] = useState('');
  const [loading, setLoading] = useState(true);
  const ex = EXERCISES[exercise];

  const formatTime = s => `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
  const score = reps > 0 ? Math.round((goodReps / reps) * 100) : 0;
  const scoreColor = score >= 80 ? '#00e676' : score >= 50 ? '#ffab00' : '#ff1744';

  // Deduplicate issues for display
  const uniqueIssues = [...new Set(issueLog)].slice(0, 5);

  useEffect(() => {
    getSessionSummary({ exercise, reps, duration, issueLog: uniqueIssues, goodReps })
      .then(text => {
        setSummary(text || 'Great session! Keep consistent and your form will improve with each workout.');
        setLoading(false);
      });
  }, []);

  return (
    <div className={styles.wrap}>
      <div className={styles.topRow}>
        <div className={styles.exTag}>{ex.icon} {ex.name}</div>
        <div className={styles.sessionLabel}>Session complete</div>
      </div>

      {/* Score ring */}
      <div className={styles.scoreSection}>
        <div className={styles.scoreRing} style={{ '--score': score, '--color': scoreColor }}>
          <svg viewBox="0 0 100 100" className={styles.ringsvg}>
            <circle cx="50" cy="50" r="42" fill="none" stroke="var(--bg3)" strokeWidth="8"/>
            <circle
              cx="50" cy="50" r="42"
              fill="none"
              stroke={scoreColor}
              strokeWidth="8"
              strokeLinecap="round"
              strokeDasharray={`${(score / 100) * 264} 264`}
              strokeDashoffset="66"
              style={{ transition: 'stroke-dasharray 1s ease' }}
            />
          </svg>
          <div className={styles.scoreInner}>
            <div className={styles.scoreNum} style={{ color: scoreColor }}>{score}</div>
            <div className={styles.scoreLabel}>form score</div>
          </div>
        </div>

        <div className={styles.statsGrid}>
          <div className={styles.stat}>
            <div className={styles.statVal}>{reps}</div>
            <div className={styles.statKey}>total reps</div>
          </div>
          <div className={styles.stat}>
            <div className={styles.statVal}>{goodReps}</div>
            <div className={styles.statKey}>good form</div>
          </div>
          <div className={styles.stat}>
            <div className={styles.statVal}>{formatTime(duration)}</div>
            <div className={styles.statKey}>duration</div>
          </div>
          <div className={styles.stat}>
            <div className={styles.statVal}>{uniqueIssues.length}</div>
            <div className={styles.statKey}>issues flagged</div>
          </div>
        </div>
      </div>

      {/* Issues found */}
      {uniqueIssues.length > 0 && (
        <div className={styles.issuesBox}>
          <div className={styles.boxLabel}>Form issues detected</div>
          {uniqueIssues.map((issue, i) => (
            <div key={i} className={styles.issueRow}>
              <div className={styles.issueDot}/>
              <div className={styles.issueText}>{issue}</div>
            </div>
          ))}
        </div>
      )}

      {/* AI Summary */}
      <div className={styles.aiBox}>
        <div className={styles.aiHeader}>
          <div className={styles.aiIcon}>
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
              <circle cx="7" cy="7" r="6" stroke="#00e676" strokeWidth="1.2"/>
              <path d="M4.5 7h5M7 4.5v5" stroke="#00e676" strokeWidth="1.2" strokeLinecap="round"/>
            </svg>
          </div>
          <span>AI Coach summary</span>
        </div>
        {loading ? (
          <div className={styles.aiLoading}>
            <div className={styles.aiDots}>
              <span/><span/><span/>
            </div>
            <span className={styles.aiLoadText}>Analyzing your session...</span>
          </div>
        ) : (
          <div className={styles.aiText}>
            {summary.split('\n').filter(Boolean).map((para, i) => (
              <p key={i}>{para}</p>
            ))}
          </div>
        )}
      </div>

      {/* Actions */}
      <div className={styles.actions}>
        <button className={styles.restartBtn} onClick={onRestart}>
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M2 8a6 6 0 1 1 1.5 4M2 12V8h4" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/></svg>
          Repeat {ex.name}
        </button>
        <button className={styles.newBtn} onClick={onNewExercise}>
          New exercise →
        </button>
      </div>
    </div>
  );
}
