import { useState } from 'react';
import styles from './BMIPage.module.css';

function getBMICategory(bmi) {
  if (bmi < 18.5) return { label: 'Underweight', color: 'var(--blue)', pct: 15 };
  if (bmi < 25) return { label: 'Normal', color: 'var(--green)', pct: 38 };
  if (bmi < 30) return { label: 'Overweight', color: 'var(--amber)', pct: 62 };
  return { label: 'Obese', color: 'var(--red)', pct: 85 };
}

export default function BMIPage() {
  const [height, setHeight] = useState(175);
  const [weight, setWeight] = useState(68.5);
  const [age, setAge] = useState(22);
  const [gender, setGender] = useState('male');

  const bmi = +(weight / ((height / 100) ** 2)).toFixed(1);
  const cat = getBMICategory(bmi);
  const tdee = gender === 'male'
    ? Math.round(88.36 + (13.4 * weight) + (4.8 * height) - (5.7 * age))
    : Math.round(447.6 + (9.2 * weight) + (3.1 * height) - (4.3 * age));
  const idealWeight = { min: +(18.5 * (height / 100) ** 2).toFixed(1), max: +(24.9 * (height / 100) ** 2).toFixed(1) };

  return (
    <div className={styles.wrap}>
      <div className={styles.grid}>
        {/* Inputs */}
        <div className={styles.card}>
          <div className={styles.cardTitle}>Your measurements</div>
          <div className={styles.genderRow}>
            <button className={`${styles.genderBtn} ${gender==='male'?styles.active:''}`} onClick={()=>setGender('male')}>Male</button>
            <button className={`${styles.genderBtn} ${gender==='female'?styles.active:''}`} onClick={()=>setGender('female')}>Female</button>
          </div>
          {[
            {label:'Height', unit:'cm', val:height, set:setHeight, min:140, max:220},
            {label:'Weight', unit:'kg', val:weight, set:setWeight, min:30, max:200, step:0.5},
            {label:'Age', unit:'yrs', val:age, set:setAge, min:10, max:80},
          ].map(f => (
            <div key={f.label} className={styles.field}>
              <div className={styles.fieldRow}>
                <label className={styles.fieldLabel}>{f.label}</label>
                <span className={styles.fieldVal}>{f.val} <span className={styles.unit}>{f.unit}</span></span>
              </div>
              <input type="range" min={f.min} max={f.max} step={f.step||1} value={f.val}
                onChange={e => f.set(f.step ? parseFloat(e.target.value) : parseInt(e.target.value))} />
            </div>
          ))}
        </div>

        {/* BMI Result */}
        <div className={styles.card}>
          <div className={styles.cardTitle}>BMI result</div>
          <div className={styles.bmiNum} style={{color: cat.color}}>{bmi}</div>
          <div className={styles.bmiCat} style={{color: cat.color}}>{cat.label}</div>
          <div className={styles.scale}>
            <div className={styles.scaleBar}/>
            <div className={styles.scaleMarker} style={{left: `${cat.pct}%`, background: cat.color}}/>
            <div className={styles.scaleCats}>
              {['Under','Normal','Over','Obese'].map(c => <span key={c}>{c}</span>)}
            </div>
          </div>
          <div className={styles.statsGrid}>
            <div className={styles.stat}><div className={styles.statVal}>{tdee}</div><div className={styles.statKey}>Daily calories (TDEE)</div></div>
            <div className={styles.stat}><div className={styles.statVal}>{idealWeight.min}–{idealWeight.max}</div><div className={styles.statKey}>Ideal weight (kg)</div></div>
            <div className={styles.stat}><div className={styles.statVal}>{(tdee * 0.3 / 4).toFixed(0)}g</div><div className={styles.statKey}>Protein target</div></div>
            <div className={styles.stat}><div className={styles.statVal}>{(tdee * 0.45 / 4).toFixed(0)}g</div><div className={styles.statKey}>Carb target</div></div>
          </div>
        </div>
      </div>

      {/* AI Recommendation */}
      <div className={styles.aiBox}>
        <div className={styles.aiLabel}>
          <div className={styles.aiDot}/>
          AI Health Insight
        </div>
        <div className={styles.aiText}>
          {cat.label === 'Normal'
            ? `Your BMI of ${bmi} is in the healthy range. Your daily calorie target is ${tdee} kcal. Focus on maintaining this with balanced macros — ${(tdee * 0.3 / 4).toFixed(0)}g protein, ${(tdee * 0.45 / 4).toFixed(0)}g carbs, ${(tdee * 0.25 / 9).toFixed(0)}g fats. Strength training 3–4x per week will help preserve muscle as you maintain weight.`
            : cat.label === 'Underweight'
            ? `Your BMI of ${bmi} suggests you're underweight. Aim for a ${Math.round(tdee * 1.15)} kcal daily surplus. Prioritize protein at ${(tdee * 0.35 / 4).toFixed(0)}g/day and compound lifts 3x/week to build lean muscle mass.`
            : `Your BMI of ${bmi} indicates ${cat.label.toLowerCase()}. A moderate 300–500 kcal daily deficit from your TDEE of ${tdee} is recommended. Prioritize protein at ${(tdee * 0.35 / 4).toFixed(0)}g/day to preserve muscle during fat loss.`
          }
        </div>
      </div>
    </div>
  );
}
