import styles from './Dashboard.module.css';

const days = ['M','T','W','T','F','S','S'];
const dayStatus = ['done','done','done','rest','done','done','today'];

export default function Dashboard({ onNavigate }) {
  const date = new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' });

  return (
    <div className={styles.wrap}>
      {/* Metric cards */}
      <div className={styles.metricsRow}>
        <div className={styles.metric}>
          <div className={styles.metricLabel}>BMI</div>
          <div className={styles.metricVal}>22.4</div>
          <div className={styles.metricSub}>Normal range</div>
          <div className={styles.metricTag} style={{background:'var(--green-dim)',color:'var(--green)'}}>Healthy</div>
        </div>
        <div className={styles.metric}>
          <div className={styles.metricLabel}>Calories today</div>
          <div className={styles.metricVal}>1,420</div>
          <div className={styles.metricSub}>/ 2,100 kcal goal</div>
          <div className={styles.metricTag} style={{background:'var(--amber-dim)',color:'var(--amber)'}}>680 left</div>
        </div>
        <div className={styles.metric}>
          <div className={styles.metricLabel}>Workout streak</div>
          <div className={styles.metricVal}>6</div>
          <div className={styles.metricSub}>days in a row</div>
          <div className={styles.metricTag} style={{background:'var(--green-dim)',color:'var(--green)'}}>Best yet</div>
        </div>
        <div className={styles.metric}>
          <div className={styles.metricLabel}>Water intake</div>
          <div className={styles.metricVal}>1.8<span style={{fontSize:14}}>L</span></div>
          <div className={styles.metricSub}>/ 3.0 L goal</div>
          <div className={styles.metricTag} style={{background:'var(--blue-dim)',color:'var(--blue)'}}>On track</div>
        </div>
      </div>

      <div className={styles.grid2}>
        {/* Weekly streak */}
        <div className={styles.card}>
          <div className={styles.cardTitle}>Weekly sessions
            <button className={styles.cardAction} onClick={() => onNavigate('posture')}>Start today →</button>
          </div>
          <div className={styles.weekRow}>
            {days.map((d, i) => (
              <div key={i} className={`${styles.dayBox} ${styles[dayStatus[i]]}`}>
                <div className={styles.dayDot}/>
                <div className={styles.dayLabel}>{d}</div>
              </div>
            ))}
          </div>
          <div className={styles.todaySession}>
            <div className={styles.sessionIcon}>💪</div>
            <div>
              <div className={styles.sessionName}>Today: Full Body</div>
              <div className={styles.sessionSub}>5 exercises · ~40 min</div>
            </div>
            <button className={styles.goBtn} onClick={() => onNavigate('posture')}>Go</button>
          </div>
        </div>

        {/* Calorie ring */}
        <div className={styles.card}>
          <div className={styles.cardTitle}>Macros today
            <button className={styles.cardAction} onClick={() => onNavigate('diet')}>Log food →</button>
          </div>
          <div className={styles.macroWrap}>
            <div className={styles.ringWrap}>
              <svg viewBox="0 0 80 80" className={styles.ring}>
                <circle cx="40" cy="40" r="32" fill="none" stroke="var(--bg3)" strokeWidth="7"/>
                <circle cx="40" cy="40" r="32" fill="none" stroke="var(--green)" strokeWidth="7"
                  strokeLinecap="round" strokeDasharray={`${(1420/2100)*201} 201`} strokeDashoffset="50"/>
              </svg>
              <div className={styles.ringInner}>
                <div className={styles.ringPct}>68%</div>
                <div className={styles.ringLabel}>eaten</div>
              </div>
            </div>
            <div className={styles.macros}>
              {[
                {name:'Protein', val:'108g', pct:72, color:'var(--blue)'},
                {name:'Carbs', val:'174g', pct:58, color:'var(--amber)'},
                {name:'Fat', val:'42g', pct:45, color:'var(--red)'},
                {name:'Fiber', val:'18g', pct:60, color:'var(--green)'},
              ].map(m => (
                <div key={m.name} className={styles.macroRow}>
                  <div className={styles.macroName}>{m.name}</div>
                  <div className={styles.macroBar}><div style={{width:`${m.pct}%`,background:m.color}}/></div>
                  <div className={styles.macroVal}>{m.val}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className={styles.grid3}>
        {/* Quick actions */}
        <div className={styles.quickCard} onClick={() => onNavigate('posture')}>
          <div className={styles.quickIcon} style={{background:'var(--green-dim)',color:'var(--green)'}}>
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="5" r="2.5" stroke="currentColor" strokeWidth="1.5"/><path d="M4 10l3 2 3-4 3 3 3-2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/><path d="M10 13v5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>
          </div>
          <div className={styles.quickLabel}>Posture check</div>
          <div className={styles.quickSub}>Live AI detection</div>
        </div>
        <div className={styles.quickCard} onClick={() => onNavigate('diet')}>
          <div className={styles.quickIcon} style={{background:'var(--amber-dim)',color:'var(--amber)'}}>
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none"><rect x="3" y="8" width="14" height="10" rx="2" stroke="currentColor" strokeWidth="1.5"/><path d="M7 8V6a3 3 0 0 1 6 0v2" stroke="currentColor" strokeWidth="1.5"/><circle cx="10" cy="13" r="1.5" fill="currentColor"/></svg>
          </div>
          <div className={styles.quickLabel}>Log meal</div>
          <div className={styles.quickSub}>Photo → calories</div>
        </div>
        <div className={styles.quickCard} onClick={() => onNavigate('bmi')}>
          <div className={styles.quickIcon} style={{background:'var(--blue-dim)',color:'var(--blue)'}}>
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none"><path d="M10 3v14M3 10h14" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/><circle cx="10" cy="10" r="7" stroke="currentColor" strokeWidth="1.5"/></svg>
          </div>
          <div className={styles.quickLabel}>BMI & health</div>
          <div className={styles.quickSub}>Update stats</div>
        </div>
        <div className={styles.quickCard} onClick={() => onNavigate('chat')}>
          <div className={styles.quickIcon} style={{background:'var(--purple-dim)',color:'var(--purple)'}}>
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none"><path d="M3 4h14a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1H7l-4 3V5a1 1 0 0 1 1-1z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round"/></svg>
          </div>
          <div className={styles.quickLabel}>AI coach</div>
          <div className={styles.quickSub}>Ask anything</div>
        </div>
      </div>
    </div>
  );
}
