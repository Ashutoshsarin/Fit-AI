import { useState } from 'react';
import styles from './DietPage.module.css';

const MEALS = [
  { time: 'Breakfast', items: [{ name: 'Oats with banana', cal: 320, p: 12, c: 58, f: 6 }, { name: '2 boiled eggs', cal: 140, p: 12, c: 1, f: 10 }] },
  { time: 'Lunch', items: [{ name: 'Dal + 2 roti', cal: 380, p: 14, c: 62, f: 8 }, { name: 'Curd (200g)', cal: 120, p: 8, c: 10, f: 4 }] },
  { time: 'Snack', items: [{ name: 'Peanut butter + apple', cal: 220, p: 7, c: 28, f: 10 }] },
  { time: 'Dinner', items: [] },
];

const DIET_CHART = [
  { day: 'Mon', meals: ['Oats + eggs', 'Dal chawal', 'Paneer bhurji + roti'] },
  { day: 'Tue', meals: ['Poha + milk', 'Rajma rice', 'Grilled chicken + salad'] },
  { day: 'Wed', meals: ['Besan chilla', 'Chole + roti', 'Moong dal + rice'] },
  { day: 'Thu', meals: ['Banana shake', 'Palak dal + rice', 'Tofu stir fry'] },
  { day: 'Fri', meals: ['Upma + curd', 'Paneer curry + roti', 'Sprouts + chapati'] },
  { day: 'Sat', meals: ['Dalia + milk', 'Mix veg + roti', 'Egg curry + rice'] },
  { day: 'Sun', meals: ['Idli + sambar', 'Rajma rice', 'Dal + roti + salad'] },
];

export default function DietPage() {
  const [logInput, setLogInput] = useState('');
  const [loggedItems, setLoggedItems] = useState([]);
  const [loading, setLoading] = useState(false);

  const totalCal = MEALS.flatMap(m => m.items).reduce((s, i) => s + i.cal, 0)
    + loggedItems.reduce((s, i) => s + i.cal, 0);
  const goal = 2100;

  const handleLog = async () => {
    if (!logInput.trim()) return;
    setLoading(true);
    // Simulate AI food parsing (replace with Claude Vision API)
    await new Promise(r => setTimeout(r, 800));
    const mockResult = { name: logInput, cal: Math.round(Math.random() * 300 + 100), p: Math.round(Math.random() * 15 + 5), c: Math.round(Math.random() * 40 + 10), f: Math.round(Math.random() * 12 + 3) };
    setLoggedItems(prev => [...prev, mockResult]);
    setLogInput('');
    setLoading(false);
  };

  return (
    <div className={styles.wrap}>
      <div className={styles.topRow}>
        {/* Calorie progress */}
        <div className={styles.calCard}>
          <div className={styles.calHeader}>
            <div>
              <div className={styles.calTitle}>Today's calories</div>
              <div className={styles.calNums}><span className={styles.calEaten}>{totalCal}</span><span className={styles.calGoal}> / {goal} kcal</span></div>
            </div>
            <div className={styles.calLeft} style={{color: totalCal > goal ? 'var(--red)' : 'var(--green)'}}>
              {totalCal > goal ? `+${totalCal - goal}` : goal - totalCal} {totalCal > goal ? 'over' : 'left'}
            </div>
          </div>
          <div className={styles.calBar}>
            <div style={{width:`${Math.min((totalCal/goal)*100,100)}%`, background: totalCal > goal ? 'var(--red)' : 'var(--green)'}}/>
          </div>
        </div>

        {/* Quick log */}
        <div className={styles.logCard}>
          <div className={styles.logTitle}>Log food</div>
          <div className={styles.logRow}>
            <input className={styles.logInput} value={logInput} onChange={e => setLogInput(e.target.value)}
              placeholder="Type food name (e.g. 2 rotis, dal...)"
              onKeyDown={e => e.key === 'Enter' && handleLog()} />
            <button className={styles.logBtn} onClick={handleLog} disabled={loading}>
              {loading ? '...' : '+ Add'}
            </button>
          </div>
          <div className={styles.logHint}>
            <svg width="12" height="12" viewBox="0 0 12 12" fill="none"><rect x="1.5" y="3" width="9" height="7" rx="1.5" stroke="currentColor" strokeWidth="1.2"/><circle cx="6" cy="6.5" r="1.5" stroke="currentColor" strokeWidth="1.2"/></svg>
            Camera food detection coming soon
          </div>
          {loggedItems.map((item, i) => (
            <div key={i} className={styles.loggedItem}>
              <span className={styles.loggedName}>{item.name}</span>
              <span className={styles.loggedCal}>{item.cal} kcal</span>
              <span className={styles.loggedMacro}>{item.p}P · {item.c}C · {item.f}F</span>
            </div>
          ))}
        </div>
      </div>

      <div className={styles.grid2}>
        {/* Meal log */}
        <div className={styles.card}>
          <div className={styles.cardTitle}>Today's meals</div>
          {MEALS.map(meal => (
            <div key={meal.time} className={styles.mealSection}>
              <div className={styles.mealTime}>{meal.time}</div>
              {meal.items.length === 0
                ? <div className={styles.mealEmpty}>Not logged yet</div>
                : meal.items.map((item, i) => (
                  <div key={i} className={styles.mealItem}>
                    <span className={styles.mealName}>{item.name}</span>
                    <span className={styles.mealCal}>{item.cal} kcal</span>
                  </div>
                ))
              }
            </div>
          ))}
        </div>

        {/* Weekly diet chart */}
        <div className={styles.card}>
          <div className={styles.cardTitle}>AI diet chart — this week</div>
          {DIET_CHART.map((d, i) => (
            <div key={d.day} className={`${styles.dietRow} ${i === new Date().getDay() - 1 ? styles.today : ''}`}>
              <div className={styles.dietDay}>{d.day}</div>
              <div className={styles.dietMeals}>
                {d.meals.map((m, j) => <span key={j} className={styles.dietMeal}>{m}</span>)}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
