import { useState } from 'react';
import DeviceSetup from '../components/DeviceSetup';
import ExercisePicker from '../components/ExercisePicker';
import PoseDetector from '../components/PoseDetector';
import SessionSummary from '../components/SessionSummary';
import styles from './PosturePage.module.css';

export default function PosturePage() {
  const [step, setStep] = useState(0);
  const [device, setDevice] = useState('laptop');
  const [exercise, setExercise] = useState('squat');
  const [sessionData, setSessionData] = useState(null);

  const handleFinish = (data) => { setSessionData(data); setStep(3); };

  return (
    <div className={styles.wrap}>
      {step < 3 && (
        <div className={styles.stepNav}>
          {['Device','Exercise','Live session'].map((s, i) => (
            <div key={s} className={`${styles.stepItem} ${i===step?styles.active:''} ${i<step?styles.done:''}`}>
              <div className={styles.stepNum}>{i < step ? '✓' : `0${i+1}`}</div>
              <div className={styles.stepLabel}>{s}</div>
            </div>
          ))}
        </div>
      )}

      <div className={styles.content}>
        {step === 0 && <DeviceSetup device={device} onDevice={setDevice} onNext={() => setStep(1)} />}
        {step === 1 && <ExercisePicker exercise={exercise} onExercise={setExercise} onNext={() => setStep(2)} onBack={() => setStep(0)} />}
        {step === 2 && <PoseDetector exercise={exercise} device={device} onBack={() => setStep(1)} onFinish={handleFinish} />}
        {step === 3 && sessionData && (
          <SessionSummary {...sessionData} onRestart={() => setStep(2)} onNewExercise={() => setStep(1)} />
        )}
      </div>
    </div>
  );
}
