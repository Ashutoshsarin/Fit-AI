import { useState, useRef, useEffect } from 'react';
import styles from './ChatPage.module.css';

const SUGGESTIONS = [
  'What should I eat before leg day?',
  'How many rest days do I need per week?',
  'Is my BMI normal for my age?',
  'Suggest a home workout plan for beginners',
  'What exercises fix knee pain?',
  'How to improve squat depth?',
];

const SYSTEM = `You are FitAI, a friendly and knowledgeable fitness coach. You specialize in:
- Exercise form and technique
- Workout programming for all levels
- Indian diet and nutrition (dal, roti, rice, etc.)
- BMI and body composition
- Injury prevention and recovery

Keep answers concise and practical. Use bullet points when listing. Be encouraging but honest.`;

export default function ChatPage() {
  const [messages, setMessages] = useState([
    { role: 'assistant', content: "Hey! I'm your FitAI coach. Ask me anything about workouts, diet, form, or recovery. I'm here to help 💪" }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef(null);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  const send = async (text) => {
    const msg = text || input.trim();
    if (!msg || loading) return;
    setInput('');
    const newMessages = [...messages, { role: 'user', content: msg }];
    setMessages(newMessages);
    setLoading(true);

    try {
      const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 400,
          system: SYSTEM,
          messages: newMessages.map(m => ({ role: m.role, content: m.content }))
        })
      });
      const data = await res.json();
      const reply = data.content?.[0]?.text || 'Sorry, I had trouble responding. Try again.';
      setMessages(prev => [...prev, { role: 'assistant', content: reply }]);
    } catch {
      setMessages(prev => [...prev, { role: 'assistant', content: 'Connection error. Please check your internet and try again.' }]);
    }
    setLoading(false);
  };

  return (
    <div className={styles.wrap}>
      <div className={styles.chatArea}>
        {messages.map((m, i) => (
          <div key={i} className={`${styles.bubble} ${m.role === 'user' ? styles.user : styles.ai}`}>
            {m.role === 'assistant' && <div className={styles.aiAvatar}>AI</div>}
            <div className={styles.bubbleText}>
              {m.content.split('\n').map((line, j) => <p key={j}>{line}</p>)}
            </div>
          </div>
        ))}
        {loading && (
          <div className={`${styles.bubble} ${styles.ai}`}>
            <div className={styles.aiAvatar}>AI</div>
            <div className={styles.typing}><span/><span/><span/></div>
          </div>
        )}
        <div ref={bottomRef}/>
      </div>

      {/* Suggestions */}
      {messages.length <= 1 && (
        <div className={styles.suggestions}>
          {SUGGESTIONS.map(s => (
            <button key={s} className={styles.suggestion} onClick={() => send(s)}>{s}</button>
          ))}
        </div>
      )}

      <div className={styles.inputRow}>
        <input
          className={styles.input}
          value={input}
          onChange={e => setInput(e.target.value)}
          placeholder="Ask your AI fitness coach..."
          onKeyDown={e => e.key === 'Enter' && !e.shiftKey && send()}
        />
        <button className={styles.sendBtn} onClick={() => send()} disabled={loading || !input.trim()}>
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M2 8l12-6-5 6 5 6-12-6z" fill="currentColor"/></svg>
        </button>
      </div>
    </div>
  );
}
